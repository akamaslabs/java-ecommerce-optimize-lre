Action()
{

	web_add_cookie("rxvt=1586943720389|1586941905590; DOMAIN=konakart.dev.akamas.io");

	web_url("Welcome.action", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/Welcome.action", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/star-empty.png", ENDITEM, 
		"Url=images/content/home_kindle-fire-hd.jpg", ENDITEM, 
		"Url=images/flags/en_GB.gif", ENDITEM, 
		"Url=styles/font-awesome/fonts/fontawesome-webfont.eot", ENDITEM, 
		"Url=images/arrow-left-inactive.png", ENDITEM, 
		"Url=images/arrow-down-hover.png", ENDITEM, 
		"Url=images/arrow-right.png", ENDITEM, 
		"Url=images/flags/de_DE.gif", ENDITEM, 
		"Url=images/flags/pt_BR.gif", ENDITEM, 
		"Url=images/flags/es_ES.gif", ENDITEM, 
		"Url=images/green-circle.png", ENDITEM, 
		LAST);

	web_add_cookie("rxVisitor=158694190558578R3D1CJ1PPA1IRTB9BI4E7JVEH8H1KR; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("dtPC=4$541905561_36h1vFBBNKELQQUPFPLNGUJCSRKUMMSPBEPIQ-0; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("rxvt=1586943715740|1586941905590; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("dtSa=-; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("dtLatC=4; DOMAIN=konakart.dev.akamas.io");

	web_custom_request("rb_bf59725eih", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/rb_bf59725eih?app=ea7c4b59f27d43eb;end=1", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/Welcome.action", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C1%7C_load_%7C_load_%7C-%7C1586941904999%7C0%7C-1$svrid=4$PV=1$rId=RID_1275878254$rpId=1287793029$url=http%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2FWelcome.action$title=KonaKart$latC=4$app=ea7c4b59f27d43eb$visitID=FBBNKELQQUPFPLNGUJCSRKUMMSPBEPIQ-0$vs=1$fId=541905561_36$v=10189200406084516$time=1586941915738$cs=-42319761", 
		EXTRARES, 
		"Url=../favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("rxvt=1586943720822|1586941905590; DOMAIN=konakart.dev.akamas.io");

	web_custom_request("rb_bf59725eih_2", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/rb_bf59725eih?app=ea7c4b59f27d43eb;end=1", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/Welcome.action", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C1%7C_load_%7C_load_%7C-%7C1586941904999%7C1586941920373%7C570%2C2%7C2%7C_onload_%7C_load_%7C-%7C1586941920372%7C1586941920372%7C570$svrid=4$rId=RID_1275878254$rpId=1287793029$domR=1586941920363$w=1252$h=608$sw=2560$sh=1440$nt=a0b1586941904999e0f9g9h9i9k9l9m99n9o13053p13053q13054r15364s15373t15373$VE=145%7C292%7C292950%7Ct%3BIMG$V=14075|c$S=13438$fd=j3.3.1$url=http%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2FWelcome.action$title=KonaKart$latC=4$app=ea7c4b59f27d43eb$visitID="
		"FBBNKELQQUPFPLNGUJCSRKUMMSPBEPIQ-0$vs=1$fId=541905561_36$v=10189200406084516$vID=158694190558578R3D1CJ1PPA1IRTB9BI4E7JVEH8H1KR$nV=1$nVAT=1$time=1586941920821$cs=-738970990", 
		LAST);

	web_add_cookie("dtPC=4$541905561_36h-vFBBNKELQQUPFPLNGUJCSRKUMMSPBEPIQ-0; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("rxvt=1586943726866|1586941905590; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("dtLatC=1; DOMAIN=konakart.dev.akamas.io");

	lr_think_time(5);

	web_custom_request("rb_bf59725eih_3", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/rb_bf59725eih?app=ea7c4b59f27d43eb;end=1", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/Welcome.action", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$svrid=4$3p="
		"1-1586941904999%3Bcode.jquery.com%7Cc%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C47_12943%7C12879%7C12863%7C12895%7C1%7C0%7C0%7C0%7C24_12917%7C12894%7C12894%7C12894%3Bkonakart.dev.akamas.io%7Cu%7C32%7C0%7C0%7C0%7C0%7C32%7C%7C0%7C0%7C0%7C60_1530_13122_13306_13348_14076_15738_15914%7C916%7C141%7C1441%7C14%7C0%7C0%7C0%7C0%7C14%7C%7C0%7C0%7C0%7C49_1056%7C723%7C461%7C999%7C4%7C0%7C0%7C0%7C34_667%7C392%7C147%7C621%7C1%7C0%7C0%7C0%7C13055_13592%7C538%7C538%7C538%3Bfonts.googleapis.com%7Cg%7C1%7C0%7C0%7C0%7"
		"C37_12933%7C12897%7C12897%7C12897%3Bfonts.gstatic.com%7Cg%7C4%7C0%7C0%7C0%7C13021_15193%7C1337%7C1032%7C2166$rt="
		"1-1586941904999%3Bhttps%3A%2F%2Fcode.jquery.com%2Fui%2F1.12.1%2Fthemes%2Fsmoothness%2Fjquery-ui.css%7Cb24e11730m12894K1I11%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fstyles%2Fjquery.selectboxit.css%7Cb34e1f1g1h1i1k1l146m147K1I11%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fstyles%2Ffont-awesome%2Fcss%2Ffont-awesome.css%7Cb35e5f5g5h5i5k146l482m485K1I11%7Chttps%3A%2F%2Ffonts.googleapis.com%2Fcss%3Ffamily%3DOpen%2BSans%3A400italic%5Ec600italic%5Ec400%5Ec600%5Ec700%7Cb37e11"
		"595f11598g11598h11598i11851k11851l12870m12897K1I11%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fstyles%2Fjcarousel.css%7Cb46e3f3g3h3i3k147l301m317K1I11%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fstyles%2Fkk-style.css%7Cb47e3f3g3h3i3k158l616m621K1I11%7Chttps%3A%2F%2Fcode.jquery.com%2Fjquery-3.3.1.min.js%7Cb47e11706m12863K1I12%7Chttps%3A%2F%2Fcode.jquery.com%2Fui%2F1.12.1%2Fjquery-ui.min.js%7Cb48e11717m12895K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fs"
		"cript%2Fjquery.validate.min.js%7Cb49e1f1g1h1i1k161l471m474K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fjquery.selectboxit.min.js%7Cb49e58f58g58h58i58k190l589m598K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fjquery.ui.datepicker-en.js%7Cb50e57f57g57h57i57k298l457m461K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fjquery.ui.datepicker-de.js%7Cb51e56f56g56h56i56k417l586m595K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A878"
		"0%2Fkonakart%2Fscript%2Fjquery.ui.datepicker-pt.js%7Cb52e55f55g55h55i55k475l643m664K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fjquery.ui.datepicker-es.js%7Cb53e54f54g54h54i54k485l637m639K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fddpowerzoomer.js%7Cb53e54f54g54h54i54k494l662m663K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fjquery.jcarousel.min.js%7Cb54e53f53g53h53i53k594l803m813K1I12%7Chttp%3A%2F%2Fkonakart.dev.ak"
		"amas.io%3A8780%2Fkonakart%2Fscript%2Fjquery.touchSwipe.min.js%7Cb55e53f53g53h53i53k593l789m791K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fjquery.cookie.js%7Cb55e52f52g52h52i52k609l785m791K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fjquery-backward-timer.min.js%7Cb56e51f51g51h51i51k643l833m837K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fkk.js%7Cb57e51f51g51h51i51k660l996m999K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas."
		"io%3A8780%2Fkonakart%2Fscript%2Fkk.validation.js%7Cb58e50f50g50h50i50k659l841m841K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fscript%2Fpicturefill-min.js%7Cb59e49f49g49h49i49k788l947m948K1I12%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fcontent%2Flogo.png%7Cb60e48f48g48h48i48k787l981m1043I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fcontent%2Fhome_5Felectronics-sale.jpg%7Cb61e47f47g47h47i47k806l960m1047I7%7Chttp%3A%2F%2Fkonakart.dev."
		"akamas.io%3A8780%2Fkonakart%2Fimages%2Fcontent%2Fhome_5Felectronics-sale-2.jpg%7Cb62e46f46g46h46i46k830l966m1047I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fcontent%2Fhome_5Fgifts-for-the-home.jpg%7Cb63e45f45g45h45i45k836l990m1039I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fcontent%2Fhome_5Fiphone-5.jpg%7Cb64e44f44g44h44i44k942l1099m1101I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F8%2F6%2FD%2F7%2F86D70649-28A3-492D-A"
		"18E-B6BB0934EB7C_5F1_5Fmedium.jpg%7Cb64e44f44g44h44i44k962l1121m1125I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2FC%2F0%2F2%2FC%2FC02C89ED-CB73-4150-BB41-0726DEE2E5A1_5F1_5Fmedium.jpg%7Cb65e43f43g43h43i43k980l1125m1130I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F3%2F1%2F1%2F1%2F3111B14C-0BC1-45E4-A4F9-968DAD99B6F2_5F1_5Fmedium.jpg%7Cb65e43f43g43h43i43k980l1153m1154I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fpr"
		"od%2F5%2F4%2FF%2FD%2F54FDD302-5B74-4075-8C2E-B9E11A0EEF2E_5F1_5Fmedium.jpg%7Cb66e42f42g42h42i42k990l1129m1134I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2FE%2F7%2FB%2F8%2FE7B8896B-3199-4C4A-966D-9CCD3EFAA33C_5F1_5Fmedium.jpg%7Cb67e41f41g41h41i41k990l1144m1149I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2FF%2FF%2F0%2F6%2FFF06923B-46B1-4F4B-9A6F-A68276A56FE5_5F1_5Fmedium.jpg%7Cb68e41f41g41h41i41k1095l1228m1229I7%7Chttp%3A%2F%2Fkonakart.dev"
		".akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F1%2F0%2F3%2F0%2F10301426-3620-418E-AF4D-4319F708E564_5F1_5Fmedium.jpg%7Cb69e40f40g40h40i40k1119l1267m1269I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2FA%2F8%2F6%2FC%2FA86C794E-5C00-4F5D-8D01-121C01E6A470_5F1_5Fmedium.jpg%7Cb70e39f39g39h39i39k1124l1261m1264I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F5%2FE%2F8%2F9%2F5E89B135-269C-4094-81F1-A71C98D1412A_5F1_5Fmedium.jpg%7Cb78e30f30g30h30i30k"
		"1121l1279m1283I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2FE%2FC%2FD%2F2%2FECD283D0-BFFD-4639-8B08-965C3470B895_5F1_5Fmedium.jpg%7Cb83e25f25g25h25i25k1132l1280m1281I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2FF%2F9%2F8%2FF%2FF98F155B-2D6D-41C0-897F-3071B6354AD8_5F1_5Fmedium.jpg%7Cb84e24f24g24h24i24k1134l1291m1292I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F1%2F5%2FF%2F8%2F15F8FBB1-13DA-4A47-B3D2-0F1E7BE"
		"CAE7C_5F1_5Fmedium.jpg%7Cb85e23f23g23h23i23k1248l1396m1401I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F4%2FA%2F6%2FB%2F4A6B2621-4689-41D7-9BB6-9C2A4200F39E_5F1_5Fmedium.jpg%7Cb86e22f22g22h22i22k1210l1343m1344I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F9%2F5%2F7%2F8%2F95782936-65F3-448F-BF8E-A0F5409B5048_5F1_5Fmedium.jpg%7Cb87e21f21g21h21i21k1249l1388m1392I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F1%2"
		"F1%2FB%2FC%2F11BC0D25-1B08-4141-BABB-1B1E633CB382_5F1_5Fmedium.jpg%7Cb88e21f21g21h21i21k1273l1400m1401I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2FA%2F2%2F1%2FC%2FA21CA25F-645B-4D88-9539-1407737EC790_5F1_5Fmedium.jpg%7Cb88e20f20g20h20i20k1275l1413m1414I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fprod%2F9%2F4%2FC%2FA%2F94CA0B48-0BCA-4696-A688-93C626E120F0_5F1_5Fmedium.jpg%7Cb89e19f19g19h19i19k1286l1440m1441I7%7Chttps%3A%2F%2Ffonts.gstatic.com"
		"%2Fs%2Fopensans%2Fv17%2Fmem6YaGs126MiZpBA-UFUK0Zdcs.woff%7Cb13021e625f627g627h627i786k786l928m1032I9%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv17%2FmemnYaGs126MiZpBA-UFUKXGUdhrIqU.woff%7Cb13025e621f623g623h623i844k844l929m1047I9%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv17%2Fmem8YaGs126MiZpBA-UFVZ0d.woff%7Cb13026e622f624g624h624i948k948l1075m1103I9%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv17%2Fmem5YaGs126MiZpBA-UN7rgOUuhv.woff%7Cb13027e651f655g655h655i1107k1107l2125m"
		"2166I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fstyles%2Ffont-awesome%2Ffonts%2Ffontawesome-webfont.eot%3F%23iefix%26v%3D4.1.0%7Cb13055e1f1g1h1i1k1l537m538I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fstar-empty.png%7Cb13122e1f1g1h1i1k1l154m184I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fcontent%2Fhome_5Fkindle-fire-hd.jpg%7Cb13348e1f1g1h1i1k1l157m728E2F292950I7%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fflag"
		"s%2Fen_5FGB.gif%7Cb13354e43f43g43h43i43k43l173m174E1F126I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Farrow-down-hover.png%7Cb13361e40f40g40h40i40k40l216m224F28I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Farrow-left-inactive.png%7Cb13373e28f28g28h28i28k29l200m212I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Farrow-right.png%7Cb13374e30f30g30h30i30k40l211m216I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2F"
		"flags%2Fde_5FDE.gif%7Cb15738e1f1g1h1i1k1l144m154I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fflags%2Fes_5FES.gif%7Cb15739e1f1g1h1i1k1l161m161I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fflags%2Fpt_5FBR.gif%7Cb15741e1f1g1h1i1k1l154m158I9%7Chttp%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2Fimages%2Fgreen-circle.png%7Cb15773e1f1g1h1i1k1l140m141I9$url=http%3A%2F%2Fkonakart.dev.akamas.io%3A8780%2Fkonakart%2FWelcome.action$title=KonaKart$latC=1$app"
		"=ea7c4b59f27d43eb$visitID=FBBNKELQQUPFPLNGUJCSRKUMMSPBEPIQ-0$vs=1$fId=541905561_36$v=10189200406084516$vID=158694190558578R3D1CJ1PPA1IRTB9BI4E7JVEH8H1KR$time=1586941926865$cs=1651307419", 
		LAST);

	return 0;
}
