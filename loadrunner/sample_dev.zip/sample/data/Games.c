Games()
{

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("SelectCat.action_2", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/SelectCat.action?catId=2", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/Welcom.action", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/content/black-ops-2.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/1_2_-1_-1.action", ENDITEM, 
		"Url=images/content/winter-deals.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/1_2_-1_-1.action", ENDITEM, 
		"Url=images/content/swat-3.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/1_2_-1_-1.action", ENDITEM, 
		"Url=images/not-selected.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_link("Activision (1)", 
		"Text=Activision (1)", 
		"Ordinal=1", 
		"Snapshot=t14.inf", 
		EXTRARES, 
		"Url=images/selected.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_link("Activision (1)_2", 
		"Text=Activision (1)", 
		"Ordinal=1", 
		"Snapshot=t15.inf", 
		LAST);

	web_add_cookie("__atuvc=2%7C28; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("__atuvs=5f06f9209d07d346001; DOMAIN=konakart.dev.akamas.io");

	web_link("SWAT 3: Close Quarters Battle", 
		"Text=SWAT 3: Close Quarters Battle", 
		"Snapshot=t16.inf", 
		EXTRARES, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_1_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_1_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_2_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_2_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_3_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_3_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_4_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_4_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		"Url=images/prod/C/4/9/4/C4941395-021B-4C97-B46C-A4491AD3D620_1_tiny.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("AddToCartOrWishListFromPost.action", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/AddToCartOrWishListFromPost.action?xsrf_token=null&random=1594292534245&addToWishList=false&prodId=21&wishListId=-1&prodQuantity=1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("SelectCat.action_3", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/SelectCat.action?catId=2", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Simulation/Sierra/SWAT-3%3A-Close-Quarters-Battle/PC-SWAT3/2_21.action", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_link("Strategy (2)", 
		"Text=Strategy (2)", 
		"Ordinal=1", 
		"Snapshot=t19.inf", 
		LAST);

	web_add_header("Origin", 
		"http://konakart.dev.akamas.io:8780");

	lr_think_time(4);

	web_submit_form("SortProd.action", 
		"Ordinal=1", 
		"Snapshot=t20.inf", 
		ITEMDATA, 
		"Name=orderBy", "Value=Most Sold", ENDITEM, 
		LAST);

	web_add_cookie("__atuvc=3%7C28; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("__atuvs=5f06f9209d07d346002; DOMAIN=konakart.dev.akamas.io");

	web_link("Disciples: Sacred Lands", 
		"Text=Disciples: Sacred Lands", 
		"Snapshot=t21.inf", 
		EXTRARES, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_1_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_1_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_2_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_2_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_3_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_3_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_4_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_4_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		"Url=images/prod/3/8/3/B/383B8D87-B3EA-4AAF-B0AB-9614C17463F3_1_tiny.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("AddToCartOrWishListFromPost.action_2", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/AddToCartOrWishListFromPost.action?xsrf_token=null&random=1594292549116&addToWishList=false&prodId=24&wishListId=-1&prodQuantity=9", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
