DVD()
{

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("SelectCat.action_4", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/SelectCat.action?catId=3", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/Games/Strategy/GT-Interactive/Disciples%3A-Sacred-Lands/PC-DISC/2_24.action", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/content/dark-knight.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/1_3_-1_-1.action", ENDITEM, 
		"Url=images/content/harry-potter.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/1_3_-1_-1.action", ENDITEM, 
		"Url=images/content/movie-deals.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/1_3_-1_-1.action", ENDITEM, 
		LAST);

	web_add_cookie("__atuvc=4%7C28; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("__atuvs=5f06f9209d07d346003; DOMAIN=konakart.dev.akamas.io");

	web_link("Harry Potter - The Goblet of Fire", 
		"Text=Harry Potter - The Goblet of Fire", 
		"Snapshot=t24.inf", 
		EXTRARES, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_1_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_2_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_1_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_2_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_3_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_3_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_4_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_4_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		"Url=images/prod/3/F/D/D/3FDD11D0-C6F2-45D0-B906-7DDFDA015594_1_tiny.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("AddToCartOrWishListFromPost.action_3", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/AddToCartOrWishListFromPost.action?xsrf_token=null&random=1594292571061&addToWishList=false&prodId=11&wishListId=-1&prodQuantity=1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("SelectCat.action_5", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/SelectCat.action?catId=3", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/DVD-Movies/Action/Warner/Harry-Potter---The-Goblet-of-Fire/DVD-FDBL/2_11.action", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	lr_think_time(4);

	web_link("Lionsgate (1)", 
		"Text=Lionsgate (1)", 
		"Ordinal=1", 
		"Snapshot=t27.inf", 
		LAST);

	web_add_header("Origin", 
		"http://konakart.dev.akamas.io:8780");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("AddToCartFromProdId.action", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/AddToCartFromProdId.action", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/FilterSearchByManufacturer.action?manuId=11&t=1594292575167", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={\"prodId\":\"4\",\"xsrf_token\":\"null\"}", 
		EXTRARES, 
		"Url=images/prod/9/3/E/E/93EE9E10-709E-4517-9041-D07C577AFBC9_1_tiny.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/FilterSearchByManufacturer.action?manuId=11&t=1594292575167", ENDITEM, 
		LAST);

	return 0;
}
