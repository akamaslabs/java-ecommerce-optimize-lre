Homepage()
{

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_cookie("__atuvc=1%7C28; DOMAIN=konakart.dev.akamas.io");

	web_add_cookie("__atuvs=5f06f9209d07d346000; DOMAIN=konakart.dev.akamas.io");

	web_url("konakart.dev.akamas.io:8780", 
		"URL=http://konakart.dev.akamas.io:8780/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", ENDITEM, 
		"Url=/konakart/images/content/home_kindle-fire-hd.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Welcome.action", ENDITEM, 
		"Url=/konakart/images/star-empty.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		"Url=/konakart/images/flags/en_GB.gif", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		"Url=/konakart/images/arrow-down-hover.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/jquery.selectboxit.css", ENDITEM, 
		"Url=/konakart/images/arrow-left-inactive.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/jcarousel.css", ENDITEM, 
		"Url=/konakart/images/arrow-right.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		"Url=/konakart/styles/font-awesome/fonts/fontawesome-webfont.woff?v=4.1.0", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/font-awesome/css/font-awesome.css", ENDITEM, 
		"Url=/konakart/images/green-circle.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		"Url=/konakart/images/arrow-right-inactive.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		"Url=/konakart/images/star-empty-big.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_link("De'Longhi BCO 410", 
		"Text=De'Longhi BCO 410", 
		"Snapshot=t9.inf", 
		EXTRARES, 
		"Url=images/prod/F/9/8/F/F98F155B-2D6D-41C0-897F-3071B6354AD8_1_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Home-%26-Garden/Kitchen/DeLonghi/De%27Longhi-BCO-410/DLBCO410/2_33.action", ENDITEM, 
		"Url=images/prod/F/9/8/F/F98F155B-2D6D-41C0-897F-3071B6354AD8_1_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Home-%26-Garden/Kitchen/DeLonghi/De%27Longhi-BCO-410/DLBCO410/2_33.action", ENDITEM, 
		"Url=images/prod/F/9/8/F/F98F155B-2D6D-41C0-897F-3071B6354AD8_2_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Home-%26-Garden/Kitchen/DeLonghi/De%27Longhi-BCO-410/DLBCO410/2_33.action", ENDITEM, 
		"Url=images/prod/F/9/8/F/F98F155B-2D6D-41C0-897F-3071B6354AD8_2_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Home-%26-Garden/Kitchen/DeLonghi/De%27Longhi-BCO-410/DLBCO410/2_33.action", ENDITEM, 
		"Url=images/prod/F/9/8/F/F98F155B-2D6D-41C0-897F-3071B6354AD8_3_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Home-%26-Garden/Kitchen/DeLonghi/De%27Longhi-BCO-410/DLBCO410/2_33.action", ENDITEM, 
		"Url=images/prod/F/9/8/F/F98F155B-2D6D-41C0-897F-3071B6354AD8_4_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Home-%26-Garden/Kitchen/DeLonghi/De%27Longhi-BCO-410/DLBCO410/2_33.action", ENDITEM, 
		"Url=images/prod/F/9/8/F/F98F155B-2D6D-41C0-897F-3071B6354AD8_4_small.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Home-%26-Garden/Kitchen/DeLonghi/De%27Longhi-BCO-410/DLBCO410/2_33.action", ENDITEM, 
		"Url=images/prod/F/9/8/F/F98F155B-2D6D-41C0-897F-3071B6354AD8_3_big.jpg", "Referer=http://konakart.dev.akamas.io:8780/konakart/Home-%26-Garden/Kitchen/DeLonghi/De%27Longhi-BCO-410/DLBCO410/2_33.action", ENDITEM, 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_image("KonaKart logo", 
		"Alt=KonaKart logo", 
		"Snapshot=t12.inf", 
		LAST);

	return 0;
}
