Checkout()
{

	web_add_header("Origin", 
		"http://konakart.dev.akamas.io:8780");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(9);

	web_custom_request("AgreeToCookies.action", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/AgreeToCookies.action", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/FilterSearchByManufacturer.action?manuId=11&t=1594292575167", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={\"\":\"\"}", 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("ShowCartItems.action", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/ShowCartItems.action", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/FilterSearchByManufacturer.action?manuId=11&t=1594292575167", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/info.png", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_url("EditCartSubmit.action", 
		"URL=http://konakart.dev.akamas.io:8780/konakart/EditCartSubmit.action?action=q&id=2&qty=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/ShowCartItems.action", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://konakart.dev.akamas.io:8780");

	lr_think_time(5);

	web_submit_data("EditCartSubmit.action_2", 
		"Action=http://konakart.dev.akamas.io:8780/konakart/EditCartSubmit.action", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/EditCartSubmit.action?action=q&id=2&qty=1", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=xsrf_token", "Value=null", ENDITEM, 
		"Name=goToCheckout", "Value=false", ENDITEM, 
		"Name=prodQty", "Value=1", ENDITEM, 
		"Name=prodQty", "Value=1", ENDITEM, 
		"Name=prodQty", "Value=1", ENDITEM, 
		"Name=prodQty", "Value=1", ENDITEM, 
		"Name=couponCode", "Value=123456", ENDITEM, 
		EXTRARES, 
		"Url=images/loader.gif", "Referer=http://konakart.dev.akamas.io:8780/konakart/styles/kk-style.css", ENDITEM, 
		LAST);

	web_submit_data("EditCartSubmit.action_3", 
		"Action=http://konakart.dev.akamas.io:8780/konakart/EditCartSubmit.action", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://konakart.dev.akamas.io:8780/konakart/EditCartSubmit.action", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=xsrf_token", "Value=null", ENDITEM, 
		"Name=goToCheckout", "Value=true", ENDITEM, 
		"Name=prodQty", "Value=1", ENDITEM, 
		"Name=prodQty", "Value=1", ENDITEM, 
		"Name=prodQty", "Value=1", ENDITEM, 
		"Name=prodQty", "Value=1", ENDITEM, 
		"Name=couponCode", "Value=123456", ENDITEM, 
		LAST);

	web_submit_form("SelectCurrency.action", 
		"Snapshot=t34.inf", 
		ITEMDATA, 
		"Name=currencyCode", "Value=EUR €", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_image("KonaKart logo_2", 
		"Alt=KonaKart logo", 
		"Snapshot=t35.inf", 
		LAST);

	return 0;
}